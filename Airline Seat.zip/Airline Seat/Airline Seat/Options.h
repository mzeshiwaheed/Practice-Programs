//
//  Options.h
//  Airline Seat
//
//  Created by Muhammad Waheed on 20.9.2022.
//

#ifndef Options_h
#define Options_h


//Category Structure
struct category {
    
    char class[20];
};


struct seat {
    
    char  aisle[15];
    char  window[15];
    char  center[15];
    
};


#endif /* Options_h */
