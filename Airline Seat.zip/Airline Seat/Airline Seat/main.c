//
//  main.c
//  Airline Seat
//
//  Created by Muhammad Waheed on 20.9.2022.
//
//This is a simple Airline seat reservation system. It is created for practice purposes only. Please use, edit and modify was such

#include <stdio.h>
#include "Options.h"
#include "string.h"
//#include "functions.h"



int main() {
    // insert code here...
    
    
    int s[10]={};
    for (int j=0; j<10; j++)
    {
    printf("***Welcome to the Qatar Airways Seat Reservation System*** \n\n");
    
    printf("            ***Please choose an option below***\n\n");
    
    
    //options for airline classes
    struct category classone;
    struct category classtwo;
    struct category classthree;
    
        
    struct seat option1;
    struct seat option2;
    struct seat option3;
    
    strcpy(classone.class,   "Business Class");
    strcpy(classtwo.class,   "Economy  Class");
    strcpy(classthree.class, "Basic Class");
        
    strcpy(option1.aisle,    "1.Aisle Seat");
    strcpy(option2.window,   "2.Window Seat");
    strcpy(option3.center,   "3.center Seat");
    
    //Printing the available options
    printf("1. %s\n",classone.class);
    printf("2. %s\n",classtwo.class);
    printf("3. %s\n",classthree.class);
    
    
    int option;
    int i;
    int location;
    scanf("%d", &option);
        
  // switch for choosing flight class, Business, Economy, Basic
  switch (option)
  {
    case 1:
          printf("The following seats are available in Business Class \n\n");
          printf("                    1,2,3,4,5.\n");
          printf("        Please choose a seat location:... \n\n  %s %s %s \n",option1.aisle,option2.window,option3.center);
          scanf("%d",&location);
          
          
          // Switch for Seat location Aisle, Window Or Center
          switch(location)
              {
              case 1:
           printf("The following seats are available  at Aisle 1,3\n\n");
                  
                  do
                  {
                      
                      printf("\nPick a seat:\n\n");
                      int seat;
                      scanf("%i",&seat);
                      s[j]=seat;
                      for (i=0; i<j; i++)
                      {
                          if (s[j]==s[i])
                          {
                              printf("\n\nSeat taken.\n\n");
                              break;
                          }
                      }
                    
                  }
                  while (i!=j);
              
                  if(s[j] != 1 && s[j] !=3){
                      printf("\nWrong number!  No seat for you!\n\n");
                      break;
                  }
                  if(s[j] <= 5 )
                          
                      {
                          printf("\n");
                          printf("--------------------------\n");
                          printf("Class: First class\n");
                          printf("Seat no : %i\n",s[j]);
                          printf("Seat location Aisle\n");
                          printf("Looking Forward Welcoming You\n");
                          printf("--------------------------\n\n");
                      }
                      else
                      printf("\nWrong number!  No seat for you!\n\n");
                  break;
                
          
      case 2:
          printf("The following seats are available  at Window 2,4\n\n");
                 
                 do
                 {
                     
                     printf("\nPick a seat:\n\n");
                     int seat;
                     scanf("%i",&seat);
                     s[j]=seat;
                     for (i=0; i<j; i++)
                     {
                         if (s[j]==s[i])
                         {
                             printf("\n\nSeat taken.\n\n");
                             break;
                         }
                     }
                   
                 }
                 while (i!=j);
             
                 if(s[j] != 2 && s[j] !=4){
                     printf("\nWrong number!  No seat for you!\n\n");
                     break;
                 }
                 if(s[j] <= 5 )
                         
                     {
                         printf("\n");
                         printf("--------------------------\n");
                         printf("Class: First class\n");
                         printf("Seat no : %i\n",s[j]);
                         printf("Seat location Window\n");
                         printf("Looking Forward Welcoming You\n");
                         printf("--------------------------\n\n");
                     }
                     else
                     printf("\nWrong number!  No seat for you!\n\n");
                 break;
    case 3:
          printf("The following seats are available  at Aisle 1,3\n\n");
                 
                 do
                 {
                     
                     printf("\nPick a seat:\n\n");
                     int seat;
                     scanf("%i",&seat);
                     s[j]=seat;
                     for (i=0; i<j; i++)
                     {
                         if (s[j]==s[i])
                         {
                             printf("\n\nSeat taken.\n\n");
                             break;
                         }
                     }
                   
                 }
                 while (i!=j);
             
                 if(s[j] != 1 && s[j] !=3){
                     printf("\nWrong number!  No seat for you!\n\n");
                     break;
                 }
                 if(s[j] <= 5 )
                         
                     {
                         printf("\n");
                         printf("--------------------------\n");
                         printf("Class: First class\n");
                         printf("Seat no : %i\n",s[j]);
                         printf("Seat location Aisle\n");
                         printf("Looking Forward Welcoming You\n");
                         printf("--------------------------\n\n");
                     }
                     else
                     printf("\nWrong number!  No seat for you!\n\n");
                 break;
  }
          break;
          
          //end of seat location selector at business class
          
      case 2:
          printf("The following seats are available  in Economy Class \n");
         
            printf("6,7,8,9,10.\n");
            do
            {
                printf("Pick a seat:\n\n");
                int seat;
                scanf("%i",&seat);
                s[j]=seat;
                //system("cls");
              
                for (i=0; i<j; i++)
                {
                    if (s[j]==s[i])
                    {
                        printf("\n\nSeat taken.\n\n");
                        break;
                    }
                }
              
            }
            while (i!=j);
                if(s[j] >= 6)
                {
                    printf("\n");
                    printf("--------------------------\n");
                    printf("Class: Economy class\n");
                    printf("Seat no : %i\n",s[j]);
                    printf("--------------------------\n\n");
                }
                else
                printf("\nWrong number!  No seat for you!\n\n");
            break;
            }
    }
return 0;
}
